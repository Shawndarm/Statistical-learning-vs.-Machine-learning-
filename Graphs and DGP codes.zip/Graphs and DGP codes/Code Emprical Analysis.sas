									/****************************************************************/
									/**********************                    **********************/
									/********************** Empirical Analysis **********************/
									/**********************                    **********************/
                                    /****************************************************************/

Libname Lib_emp "C:\Users\dutau\Downloads\Graphs and DGP codes\Empirical Analysis Project";


/* Data import */
PROC IMPORT OUT = Lib_emp.Chilo
            DATAFILE="C:\Users\dutau\Downloads\chis2005_v11_small.dta"
            DBMS=STATA REPLACE;
RUN;

/* Descriptive Stats */
proc means data=Lib_emp.Chilo N mean median min max stderr
skewness kurtosis;run;

/* Correlation matrix */
PROC CORR DATA=Lib_emp.Chilo out=Lib_emp.Corr_matrix;
VAR nbdoct female age income asthma diabetes hbpressure heart arthritis partner bornus mental ;
TITLE 'Correlation matrix of the variables';
RUN;


/* Model selection */


/* Training */
proc glmselect data = Lib_emp.Chilo
outdesign =  Lib_emp.namu;
model nbdoct = female age income asthma diabetes hbpressure heart arthritis partner bornus mental /
selection = stepwise (choose = aicc stop = aicc);
run;

/* Statistical learning */
proc glmselect data=Lib_emp.Chilo seed=6 plots=(EffectSelectPct
ParmDistribution);
model nbdoct = female age income asthma diabetes hbpressure heart arthritis partner bornus mental /
selection=stepwise(choose=aicc stop=aicc);
modelAverage tables=(EffectSelectPct(all)
ParmEst(all));
run;

/* Machine learning */
proc glmselect data=Lib_emp.Chilo seed=6 plots=(EffectSelectPct
ParmDistribution);
model nbdoct = female age income asthma hbpressure heart arthritis partner bornus mental/
selection=lasso(choose=aicc stop=aicc);
modelAverage tables=(EffectSelectPct(all)
ParmEst(all));
run;


/* With log-linearisation */


/* Preprocessing */
data Lib_emp.Chilo1 ; set Lib_emp.Chilo;

lnbdoct= log(nbdoct+1);
lincome= log(income+1);
Lasthma= log(asthma+1);
ldiabetes= log(diabetes+1);
lheart= log(heart+1);
larthritis= log(arthritis+1);
lpartner=log(partner+1);
lbornus=log(bornus+1);
lmental=log(mental+1);

drop nbdoct income asthma diabetes heart arthritis partner bornus mental;
run;

/* Training */
proc glmselect data = Lib_emp.Chilo1 outdesign =Lib_emp.nama;
model lnbdoct = female age lincome lasthma hbpressure heart arthritis partner bornus mental/
selection = stepwise(choose=aicc stop= aicc);
run;

/* Statistical learning */
proc glmselect data=Lib_emp.Chilo1 seed=6 plots=(EffectSelectPct
ParmDistribution);
model lnbdoct = female age lincome asthma hbpressure heart arthritis partner bornus mental/
selection=stepwise(choose=aicc stop=aicc);
modelAverage tables=(EffectSelectPct(all)
ParmEst(all));
run;

/* Machine Learning */
proc glmselect data=Lib_emp.Chilo1 seed=6 plots=(EffectSelectPct
ParmDistribution);
model lnbdoct = female age lincome asthma hbpressure heart arthritis partner bornus mental/
selection=lasso(choose=AICC stop=aicc);
modelAverage tables=(EffectSelectPct(all)
ParmEst(all));
run;

